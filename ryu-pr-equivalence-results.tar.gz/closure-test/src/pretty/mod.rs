//! Pointer-free reimplementation of the `pretty` formatting layer.
//!
//! Semantically identical to `pretty/{mod,mantissa,exponent}.rs`, but every
//! `*p = v` store is replaced by ordinary bounds-checked slice indexing into a
//! caller-supplied `[u8; 24]`. Pointer-free replacement for the original.
//!
//! Written to answer two questions: how much speed does the safe phrasing
//! cost, and can the compiler still prove there is no panic path?

mod exponent;
mod mantissa;

use self::exponent::{write_exponent2, write_exponent3};
use self::mantissa::{write_mantissa, write_mantissa_long};
use crate::common;
use crate::d2s::{self, d2d, DOUBLE_EXPONENT_BITS, DOUBLE_MANTISSA_BITS};
use crate::digit_table::DIGIT_TABLE;
use crate::f2s::{f2d, FLOAT_EXPONENT_BITS, FLOAT_MANTISSA_BITS};

#[cfg(feature = "no-panic")]
use no_panic::no_panic;

/// Writes the two ASCII digits of `DIGIT_TABLE[d..d + 2]` at `buf[at..at + 2]`.
#[inline(always)]
fn put2(buf: &mut [u8], at: usize, d: usize) {
    buf[at] = DIGIT_TABLE[d];
    buf[at + 1] = DIGIT_TABLE[d + 1];
}

/// Print f64 to the given buffer and return number of bytes written.
///
/// At most 24 bytes will be written.
///
/// ## Special cases
///
/// This function **does not** check for NaN or infinity. If the input
/// number is not a finite float, the printed representation will be some
/// correctly formatted but unspecified numerical value.
///
/// Please check [`is_finite`] yourself before calling this function, or
/// check [`is_nan`] and [`is_infinite`] and handle those cases yourself.
///
/// [`is_finite`]: f64::is_finite
/// [`is_nan`]: f64::is_nan
/// [`is_infinite`]: f64::is_infinite
///
/// ## Example
///
/// ```
/// use std::str;
///
/// let f = 1.234f64;
///
/// let mut buffer = [0u8; 24];
/// let len = ryu::raw::format64(f, &mut buffer);
/// let print = str::from_utf8(&buffer[..len]).unwrap();
/// assert_eq!(print, "1.234");
/// ```
#[must_use]
#[cfg_attr(feature = "no-panic", no_panic)]
pub fn format64(f: f64, buf: &mut [u8; 24]) -> usize {
    let bits = f.to_bits();
    let sign = ((bits >> (DOUBLE_MANTISSA_BITS + DOUBLE_EXPONENT_BITS)) & 1) != 0;
    let ieee_mantissa = bits & ((1u64 << DOUBLE_MANTISSA_BITS) - 1);
    let ieee_exponent =
        (bits >> DOUBLE_MANTISSA_BITS) as u32 & ((1u32 << DOUBLE_EXPONENT_BITS) - 1);

    let mut index = 0usize;
    if sign {
        buf[0] = b'-';
        index += 1;
    }

    if ieee_exponent == 0 && ieee_mantissa == 0 {
        buf[index] = b'0';
        buf[index + 1] = b'.';
        buf[index + 2] = b'0';
        return sign as usize + 3;
    }

    let v = d2d(ieee_mantissa, ieee_exponent);

    let length = d2s::decimal_length17(v.mantissa) as usize;
    let k = v.exponent as isize;
    let kk = length as isize + k; // 10^(kk-1) <= v < 10^kk
    debug_assert!(k >= -324);

    if 0 <= k && kk <= 16 {
        // 1234e7 -> 12340000000.0
        let kk = kk as usize;
        write_mantissa_long(v.mantissa, buf, index + length);
        for i in length..kk {
            buf[index + i] = b'0';
        }
        buf[index + kk] = b'.';
        buf[index + kk + 1] = b'0';
        index + kk + 2
    } else if 0 < kk && kk <= 16 {
        // 1234e-2 -> 12.34
        let kk = kk as usize;
        write_mantissa_long(v.mantissa, buf, index + length + 1);
        // Shift the first kk digits left by one, over the leading digit's slot.
        // Forward order is correct because the destination precedes the source.
        let mut i = 0;
        while i < kk {
            buf[index + i] = buf[index + 1 + i];
            i += 1;
        }
        buf[index + kk] = b'.';
        index + length + 1
    } else if -5 < kk && kk <= 0 {
        // 1234e-6 -> 0.001234
        buf[index] = b'0';
        buf[index + 1] = b'.';
        let offset = (2 - kk) as usize;
        for i in 2..offset {
            buf[index + i] = b'0';
        }
        write_mantissa_long(v.mantissa, buf, index + length + offset);
        index + length + offset
    } else if length == 1 {
        // 1e30
        buf[index] = b'0' + v.mantissa as u8;
        buf[index + 1] = b'e';
        index + 2 + write_exponent3(kk - 1, buf, index + 2)
    } else {
        // 1234e30 -> 1.234e33
        write_mantissa_long(v.mantissa, buf, index + length + 1);
        buf[index] = buf[index + 1];
        buf[index + 1] = b'.';
        buf[index + length + 1] = b'e';
        index + length + 2 + write_exponent3(kk - 1, buf, index + length + 2)
    }
}

/// Print f32 to the given buffer and return number of bytes written.
///
/// At most 16 bytes will be written.
///
/// ## Special cases
///
/// This function **does not** check for NaN or infinity. If the input
/// number is not a finite float, the printed representation will be some
/// correctly formatted but unspecified numerical value.
///
/// Please check [`is_finite`] yourself before calling this function, or
/// check [`is_nan`] and [`is_infinite`] and handle those cases yourself.
///
/// [`is_finite`]: f32::is_finite
/// [`is_nan`]: f32::is_nan
/// [`is_infinite`]: f32::is_infinite
///
/// ## Example
///
/// ```
/// use std::str;
///
/// let f = 1.234f32;
///
/// let mut buffer = [0u8; 24];
/// let len = ryu::raw::format32(f, &mut buffer);
/// let print = str::from_utf8(&buffer[..len]).unwrap();
/// assert_eq!(print, "1.234");
/// ```
#[must_use]
#[cfg_attr(feature = "no-panic", no_panic)]
pub fn format32(f: f32, buf: &mut [u8; 24]) -> usize {
    let bits = f.to_bits();
    let sign = ((bits >> (FLOAT_MANTISSA_BITS + FLOAT_EXPONENT_BITS)) & 1) != 0;
    let ieee_mantissa = bits & ((1u32 << FLOAT_MANTISSA_BITS) - 1);
    let ieee_exponent = (bits >> FLOAT_MANTISSA_BITS) & ((1u32 << FLOAT_EXPONENT_BITS) - 1);

    let mut index = 0usize;
    if sign {
        buf[0] = b'-';
        index += 1;
    }

    if ieee_exponent == 0 && ieee_mantissa == 0 {
        buf[index] = b'0';
        buf[index + 1] = b'.';
        buf[index + 2] = b'0';
        return sign as usize + 3;
    }

    let v = f2d(ieee_mantissa, ieee_exponent);

    let length = common::decimal_length9(v.mantissa) as usize;
    let k = v.exponent as isize;
    let kk = length as isize + k; // 10^(kk-1) <= v < 10^kk
    debug_assert!(k >= -45);

    if 0 <= k && kk <= 13 {
        // 1234e7 -> 12340000000.0
        let kk = kk as usize;
        write_mantissa(v.mantissa, buf, index + length);
        for i in length..kk {
            buf[index + i] = b'0';
        }
        buf[index + kk] = b'.';
        buf[index + kk + 1] = b'0';
        index + kk + 2
    } else if 0 < kk && kk <= 13 {
        // 1234e-2 -> 12.34
        let kk = kk as usize;
        write_mantissa(v.mantissa, buf, index + length + 1);
        // Shift the first kk digits left by one, over the leading digit's slot.
        // Forward order is correct because the destination precedes the source.
        let mut i = 0;
        while i < kk {
            buf[index + i] = buf[index + 1 + i];
            i += 1;
        }
        buf[index + kk] = b'.';
        index + length + 1
    } else if -6 < kk && kk <= 0 {
        // 1234e-6 -> 0.001234
        buf[index] = b'0';
        buf[index + 1] = b'.';
        let offset = (2 - kk) as usize;
        for i in 2..offset {
            buf[index + i] = b'0';
        }
        write_mantissa(v.mantissa, buf, index + length + offset);
        index + length + offset
    } else if length == 1 {
        // 1e30
        buf[index] = b'0' + v.mantissa as u8;
        buf[index + 1] = b'e';
        index + 2 + write_exponent2(kk - 1, buf, index + 2)
    } else {
        // 1234e30 -> 1.234e33
        write_mantissa(v.mantissa, buf, index + length + 1);
        buf[index] = buf[index + 1];
        buf[index + 1] = b'.';
        buf[index + length + 1] = b'e';
        index + length + 2 + write_exponent2(kk - 1, buf, index + length + 2)
    }
}
