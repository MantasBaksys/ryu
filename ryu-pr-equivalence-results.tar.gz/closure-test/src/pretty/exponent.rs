use super::put2;

#[cfg_attr(feature = "no-panic", inline)]
pub fn write_exponent3(mut k: isize, buf: &mut [u8], mut at: usize) -> usize {
    let sign = k < 0;
    if sign {
        buf[at] = b'-';
        at += 1;
        k = -k;
    }

    debug_assert!(k < 1000);
    if k >= 100 {
        buf[at] = b'0' + (k / 100) as u8;
        k %= 100;
        put2(buf, at + 1, (k * 2) as usize);
        sign as usize + 3
    } else if k >= 10 {
        put2(buf, at, (k * 2) as usize);
        sign as usize + 2
    } else {
        buf[at] = b'0' + k as u8;
        sign as usize + 1
    }
}

#[cfg_attr(feature = "no-panic", inline)]
pub fn write_exponent2(mut k: isize, buf: &mut [u8], mut at: usize) -> usize {
    let sign = k < 0;
    if sign {
        buf[at] = b'-';
        at += 1;
        k = -k;
    }

    debug_assert!(k < 100);
    if k >= 10 {
        put2(buf, at, (k * 2) as usize);
        sign as usize + 2
    } else {
        buf[at] = b'0' + k as u8;
        sign as usize + 1
    }
}
