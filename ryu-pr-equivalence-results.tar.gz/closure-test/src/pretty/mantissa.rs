use super::put2;

#[cfg_attr(feature = "no-panic", inline)]
pub fn write_mantissa_long(mut output: u64, buf: &mut [u8], mut end: usize) {
    if (output >> 32) != 0 {
        // One expensive 64-bit division.
        let mut output2 = (output - 100_000_000 * (output / 100_000_000)) as u32;
        output /= 100_000_000;

        let c = output2 % 10_000;
        output2 /= 10_000;
        let d = output2 % 10_000;
        let c0 = ((c % 100) << 1) as usize;
        let c1 = ((c / 100) << 1) as usize;
        let d0 = ((d % 100) << 1) as usize;
        let d1 = ((d / 100) << 1) as usize;
        put2(buf, end - 2, c0);
        put2(buf, end - 4, c1);
        put2(buf, end - 6, d0);
        put2(buf, end - 8, d1);
        end -= 8;
    }
    write_mantissa(output as u32, buf, end);
}

/// Digits of `output` ending at `end` (exclusive), written back to front.
#[cfg_attr(feature = "no-panic", inline)]
pub fn write_mantissa(mut output: u32, buf: &mut [u8], mut end: usize) {
    while output >= 10_000 {
        let c = output - 10_000 * (output / 10_000);
        output /= 10_000;
        let c0 = ((c % 100) << 1) as usize;
        let c1 = ((c / 100) << 1) as usize;
        put2(buf, end - 2, c0);
        put2(buf, end - 4, c1);
        end -= 4;
    }
    if output >= 100 {
        let c = ((output % 100) << 1) as usize;
        output /= 100;
        put2(buf, end - 2, c);
        end -= 2;
    }
    if output >= 10 {
        let c = (output << 1) as usize;
        put2(buf, end - 2, c);
    } else {
        buf[end - 1] = b'0' + output as u8;
    }
}
